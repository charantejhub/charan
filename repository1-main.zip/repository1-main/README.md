HelloWorld
==========

A simple Java application that can be compiled into a .jar file using Maven.

To build
--------
    mvn clean package

To run
------
    java -cp target/helloworld-1.0.jar com.coveros.demo.helloworld.HelloWorld
